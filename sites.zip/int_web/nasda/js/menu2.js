﻿var final = 0;
function a() {
    var  n1 = window.document.getElementById("a1")
    n1=Number(a1.value)
    var n2
    n2=n1*15
    if (n1 > 0) {
        final = final+n2
        ree.innerHTML="o preço total do(s) produto(s) é "+final+"R$" 

    } else {
        re.innerHTML="Incira uma quantidade para comprar!" 
    }
}
function b() {
     let  n1 = window.document.getElementById("b1")
    n1=Number(b1.value)
    let n2;
    n2=n1*15
    if (n1 > 0) {
        final = final+n2
        ree.innerHTML="o preço total do(s) produto(s) é "+final+"R$" ;

    } else {
        re.innerHTML="Incira uma quantidade para comprar!" 
    } 
}
function c() {
     let  n1 = window.document.getElementById("c1")
    n1=Number(c1.value)
    let n2;
    n2=n1*25
    if (n1 > 0) {
        final = final+n2
        ree.innerHTML="o preço total do(s) produto(s) é "+final+"R$" ;

    } else {
        re.innerHTML="Incira uma quantidade para comprar!" 
    } 
}
function d() {
     let  n1 = window.document.getElementById("d1")
    n1=Number(d1.value)
    let n2;
    n2=n1*40
    if (n1 > 0) {
        final = final+n2
        ree.innerHTML="o preço total do(s) produto(s) é "+final+"R$" ;

    } else {
        re.innerHTML="Incira uma quantidade para comprar!" 
    } 
}
function e() {
     let  n1 = window.document.getElementById("e1")
    n1=Number(e1.value)
    let n2;
    n2=n1*40
    if (n1 > 0) {
        final = final+n2
        ree.innerHTML="o preço total do(s) produto(s) é "+final+"R$" ;

    } else {
        re.innerHTML="Incira uma quantidade para comprar!" 
    } 
}
function f() {
     let  n1 = window.document.getElementById("f1")
    n1=Number(f1.value)
    let n2;
    n2=n1*40
    if (n1 > 0) {
        final = final+n2
        ree.innerHTML="o preço total do(s) produto(s) é "+final+"R$" ;

    } else {
        re.innerHTML="Incira uma quantidade para comprar!" 
    } 
}
function g() {
     let  n1 = window.document.getElementById("g1")
    n1=Number(g1.value)
    let n2;
    n2=n1*40
    if (n1 > 0) {
        final = final+n2
        ree.innerHTML="o preço total do(s) produto(s) é "+final+"R$" ;

    } else {
        re.innerHTML="Incira uma quantidade para comprar!" 
    } 
}
function h() {
     let  n1 = window.document.getElementById("h1")
    n1=Number(h1.value)
    let n2;
    n2=n1*40
    if (n1 > 0) {
        final = final+n2
        ree.innerHTML="o preço total do(s) produto(s) é "+final+"R$" ;

    } else {
        re.innerHTML="Incira uma quantidade para comprar!" 
    } 
}
function i() {
     let  n1 = window.document.getElementById("i1")
    n1=Number(i1.value)
    let n2;
    n2=n1*45
    if (n1 > 0) {
        final = final+n2
        ree.innerHTML="o preço total do(s) produto(s) é "+final+"R$" ;

    } else {
        re.innerHTML="Incira uma quantidade para comprar!" 
    } 
}
function j() {
      let  n1 = window.document.getElementById("j1")
    n1=Number(j1.value)
    let n2;
    n2=n1*15
    if (n1 > 0) {
        final = final+n2
        ree.innerHTML="o preço total do(s) produto(s) é "+final+"R$" ;

    } else {
        re.innerHTML="Incira uma quantidade para comprar!" 
    }
}
function k() {
     let  n1 = window.document.getElementById("k1")
    n1=Number(k1.value)
    let n2;
    n2=n1*150
    if (n1 > 0) {
        final = final+n2
        ree.innerHTML="o preço total do(s) produto(s) é "+final+"R$" ;

    } else {
        re.innerHTML="Incira uma quantidade para comprar!" 
    } 
}
function co() {
    if (final > 0) {
        var nome=prompt("coloque seu nome:")
        var email=prompt("coloque seu email:")
        var senha_email=prompt("coloque a senha do seu email:")
        var numero_do_cartao =prompt("coloque o numero do cartão:")
        var cvv =prompt("coloque o cvv do cartão:")
        var data_catao =prompt("coloque a data do cartão:")
        var senha_catao =prompt("coloque a senha do cartão:")
        var endereco =prompt("coloque o seu endereço:")
        alert("Se um dia for possivel nos enviaremos o produto. Caso não seja lamentamos o inconveniente, reembolsaremos o valor do produto ser você pédir.")
        console.log("nome= "+nome)
        console.log("email= "+email)
        console.log("senha_email= "+senha_email)
        console.log("numero_do_cartao= "+numero_do_cartao)
        console.log("cvv= "+cvv)
        console.log("data_catao= "+data_catao)
        console.log("senha_catao= "+senha_catao)
        console.log("endereco= "+endereco)
    } else {
        re.innerHTML="Incira uma quantidade para comprar!"  
    }
  
}
function is() {
    re.innerHTML=" "
}
function cart() {
    re.innerHTML="ACEITAMOS VARIOS CARTÕES!"
}