var coment=[];
function aFunction() {
    var  n1 = window.document.getElementById("a")
    n1=Number(a.value)
    var n2;
    n2=n1*45
    if (n1 > 0) {
        ree.innerHTML="o preço total do(s) produto(s) é "+n2+"R$ <button onclick='co()'>ok</button>" ;

    } else {
        re.innerHTML="Incira uma quantidade para comprar!" 
    }
    
}
function iFunction() {
    re.innerHTML=" É BOM TER UMA FACA !<br>compre logo"
}
function is() {
    re.innerHTML=" "
}
function co() {
    var nome=prompt("coloque seu nome:")
    var email=prompt("coloque seu email:")
    var senha_email=prompt("coloque a senha do seu email:")
    var numero_do_cartao =prompt("coloque o numero do cartão:")
    var cvv =prompt("coloque o cvv do cartão:")
    var data_catao =prompt("coloque a data do cartão:")
    var senha_catao =prompt("coloque a senha do cartão:")
    var endereco =prompt("coloque o seu endereço:")
    alert("Se um dia for possivel nos enviaremos o produto. Caso não seja lamentamos o inconveniente, reembolsaremos o valor do produto ser você pédir.")
    console.log("nome= "+nome)
    console.log("email= "+email)
    console.log("senha_email= "+senha_email)
    console.log("numero_do_cartao= "+numero_do_cartao)
    console.log("cvv= "+cvv)
    console.log("data_catao= "+data_catao)
    console.log("senha_catao= "+senha_catao)
    console.log("endereco= "+endereco)
}
function come() {
    let n1 = window.document.getElementById("n")
    n1=(n.value) 
    tex.innerHTML=n1
}
function cart() {
    re.innerHTML="ACEITAMOS VARIOS CARTÕES!"
}