<?php
$n1 = $_POST['n1'];

?>